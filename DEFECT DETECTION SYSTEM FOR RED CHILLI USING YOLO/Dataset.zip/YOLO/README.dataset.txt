# Red Chilli > 2024-02-08 3:55pm
https://universe.roboflow.com/chilli-8e54f/red-chilli

Provided by a Roboflow user
License: Public Domain

